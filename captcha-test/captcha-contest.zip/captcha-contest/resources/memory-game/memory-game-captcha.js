//card options
const cardArray = [
  {
    name: 'cat',
    img: 'resources/memory-game/images/cat1.png'
  },
  {
    name: 'fire-hydrant',
    img: 'resources/memory-game/images/fire-hydrant1.png'
  },
  {
    name: 'pizza',
    img: 'resources/memory-game/images/pizza1.png'
  },
  {
    name: 'cat',
    img: 'resources/memory-game/images/cat2.png'
  },
  {
    name: 'fire-hydrant',
    img: 'resources/memory-game/images/fire-hydrant2.png'
  },
  {
    name: 'pizza',
    img: 'resources/memory-game/images/pizza2.png'
  }
]

const grid = document.querySelector('.grid')
const resultDisplay = document.querySelector('#result')
var captchaModal = new bootstrap.Modal(document.getElementById('captchaModal'), {
  keyboard: false
})

let cardsChosen = []
let cardsChosenId = []
let cardsWon = []

var gameCaptchaValidated = false
var gameStarted = false

//start game
function startCaptchaGame() {
  //clear grid
  grid.innerHTML = "";

  //shuffle cards
  shuffleCards()

  //initialize/re-initialize elements
  cardsChosen = []
  cardsChosenId = []
  cardsWon = []
  gameCaptchaValidated = false 
  gameStarted = false
  document.getElementById("submit").disabled = true;

  //create board
  for (let i = 0; i < cardArray.length; i++) {
    const card = document.createElement('img')
    card.setAttribute('src', cardArray[i].img)
    card.setAttribute('class', 'memory-game-card')
    card.setAttribute('data-id', i)
    card.addEventListener('click', flipCard)
    grid.appendChild(card)
  }
  setTimeout(hideCards, 2500)
}

function shuffleCards() {
  for (let i = cardArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * i)
    const temp = cardArray[i]
    cardArray[i] = cardArray[j]
    cardArray[j] = temp
  }
}

function hideCards() {
  var cards = document.querySelectorAll('.memory-game-card')
  for (let i = 0; i < cardArray.length; i++) {
    cards[i].setAttribute('src', 'resources/memory-game/images/blank.png')
  }
  gameStarted = true
}

function checkForMatch() {
  if (gameStarted) {
    const cards = document.querySelectorAll('.memory-game-card')
    const optionOneId = cardsChosenId[0]
    const optionTwoId = cardsChosenId[1]

    //same image
    if (optionOneId == optionTwoId) {
      cards[optionOneId].setAttribute('src', 'resources/memory-game/images/blank.png')
      cards[optionTwoId].setAttribute('src', 'resources/memory-game/images/blank.png')
      alert('You clicked the same image!')
    }

    //correct match
    else if (cardsChosen[0] === cardsChosen[1]) {
      cards[optionOneId].setAttribute('src', 'resources/memory-game/images/check.png')
      cards[optionTwoId].setAttribute('src', 'resources/memory-game/images/check.png')
      cards[optionOneId].removeEventListener('click', flipCard)
      cards[optionTwoId].removeEventListener('click', flipCard)
      cardsWon.push(cardsChosen)
    }

    //invalid match
    else {
      cards[optionOneId].setAttribute('src', 'resources/memory-game/images/blank.png')
      cards[optionTwoId].setAttribute('src', 'resources/memory-game/images/blank.png')
      alert('Sorry, try again.')
    }

    cardsChosen = []
    cardsChosenId = []

    if (cardsWon.length === cardArray.length / 2) {
      alert('Captcha Game Validation Success')
      setTimeout(hideCaptchaModal, 400)
      document.getElementById("submit").disabled = false;
      gameCaptchaValidated = true
    }
  }
}

function flipCard() {
  if (cardsChosen.length < 2) {
    let cardId = this.getAttribute('data-id')
    cardsChosen.push(cardArray[cardId].name)
    cardsChosenId.push(cardId)
    this.setAttribute('src', cardArray[cardId].img)
    if (cardsChosen.length === 2) {
      setTimeout(checkForMatch, 150)
    }
  }
}

function hideCaptchaModal () {
  captchaModal.hide()
}

