Email: jethromatubis@yahoo.com
Entry: Double Authentication Captcha Memory Game (JavaScript/AJAX + Recaptcha V3)

How to run:
- Have a webserver (e.g. XAMPP)
- Run Apache on your webserver
- Copy folder"captcha-contest" to htdocs
- In your browser, navigate to http://localhost/captcha-contest/contact-us.php

How it works / How my captcha is different?
- What's better than 1 Captcha? 2 Captchas! 😂 My captcha introduces the memory game concept! Images are temporarily displayed before asking the user to match them. The images are also not identical - an example of this is that the user could match an icon of a pizza with the actual image of a pizza. This aims to make it harder for AI to distinguish items. 3 pairs of images are used for the memory game so as to lessen the time it takes to complete it. Also, if the user manages to bypass the memory game captcha, a Recaptcha v3 is also provided for an extra layer of security. Current limitations is that there are only 3 pairs of images. This captcha implementation is still at its MVP stage (only started working on this the night before the deadline). There are still room for improvements but hopefully the concept was demonstrated.






