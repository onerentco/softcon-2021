<?php

/* Recaptcha V2 */
if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $message = $_POST['message'];
    $secretKey = '6LeHeGodAAAAAMkiM49YuPWuET-9AQ88mWCGGsVp';
    $responseKey = $_POST['g-recaptcha-response'];

    $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$responseKey";
    $response = json_decode(file_get_contents($url));

    $response = [
        'success'   => $response->success,
        'email'     => $email,
        'message'   => $message,
        'response'  => $response
    ];

    echo json_encode($response);
}