<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Captcha Contest</title>

    <link rel="stylesheet" type="text/css" href="./resources/css/result-light.css">
    <script type="text/javascript" src="./resources/js/jquery-3.4.1.slim.js"></script>
    <link rel="stylesheet" type="text/css" href="./resources/css/bootstrap5.min.css">
    <script type="text/javascript" src="./resources/js/bootstrap5.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./resources/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="./resources/css/main.css">
    <link rel="stylesheet" href="./resources/memory-game/style.css">

    <!-- Recaptcha V3-->
    <script>
        function onSubmit('token') {
            document.getElementById("sample_form").submit();
        }
    </script>
</head>

<body data-new-gr-c-s-check-loaded="14.1040.0" data-gr-ext-installed="">

    <div class="demo-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-12 mx-auto">
                    <div class="text-center image-size-small position-relative">
                        <img src="./resources/img/message.png" class="rounded-circle p-2 bg-white">
                    </div>
                    <div class="p-5 bg-white rounded shadow-lg">
                        <h3 class="mb-2 text-center pt-5">Contact Us</h3>
                        <p class="text-center lead">Send us your questions and feedback</p>

                        <form id="sample_form">
                            <label class="font-500">Email</label>
                            <input name="email" class="form-control form-control-lg mb-3 form_data" type="email" required>

                            <label class="font-500">Message </label>
                            <div class="form-group">
                                <textarea name="message" class="form-control form_data" rows="3" required></textarea>
                            </div>

                            <input type="hidden" id="g-recaptcha-response" class="form_data" name="g-recaptcha-response" />

                            <!-- Captcha trigger modal -->
                            <button type="button" class="btn btn-secondary mt-4" data-bs-toggle="modal" data-bs-target="#captchaModal" onclick="startCaptchaGame()">
                                Validate Humanity
                            </button>

                            <button type="button" name="submit" id="submit" class="btn btn-primary btn-lg mt-4 w-100 shadow-lg g-recaptcha" onclick="save_data(); return false;" data-sitekey="reCAPTCHA_site_key" data-callback='onSubmit' data-action='submit' disabled>Submit</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Captcha modal -->
    <div class="modal fade" id="captchaModal" tabindex="-1" aria-labelledby="captchaModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="captchaModalLabel">Match the items:</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <div id="captcha-board" class="grid mx-auto">
            </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary " onclick="startCaptchaGame()">Reset</button>
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>

    <!-- Recaptcha V3-->
    <script src="https://www.google.com/recaptcha/api.js?render=6LeHeGodAAAAAJw6LEk2w2LvBxNy-vg4nMoeZn1P"></script>
    <script> 
        grecaptcha.ready(function() {
            grecaptcha.execute('6LeHeGodAAAAAJw6LEk2w2LvBxNy-vg4nMoeZn1P', {action: 'homepage'})
                .then(function(token) {
                    document.getElementById('g-recaptcha-response').value=token;
            });
        });
    </script>

    <!-- Memory Game Captcha -->
    <script type="text/javascript" src="./resources/memory-game/memory-game-captcha.js" charset="utf-8"></script>

    <script>
        function save_data() {
            var form_element = document.getElementsByClassName('form_data');
            var form_data = new FormData();

            for (var i = 0; i < form_element.length; i++) {
                form_data.append(form_element[i].name, form_element[i].value);
            }

            if(!gameCaptchaValidated){
                form_data.append('g-recaptcha-response','wenkwenk');
            }

            var ajax_request = new XMLHttpRequest();
            ajax_request.open('POST', 'post.php');
            ajax_request.send(form_data);

            ajax_request.onreadystatechange = function() {
                if (ajax_request.readyState == 4 && ajax_request.status == 200) {
                    var response = JSON.parse(ajax_request.responseText);

                    if (response.success == true) {
                        //success
                        alert('Verification success!');
                    } else {
                        //fail
                        alert('Verification fail.');
                    }
                }

                location.reload();
            }
        }
    </script>
</body>

</html>